import DAO.ProductDAO;
import Model.Product;
import View.gui;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {

                gui gui = new gui();
                gui.setVisible(true);
            }
        });
    }
}