package View;

import DAO.ProductDAO;
import Model.Product;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class gui extends JFrame {
    private JTextField idField, codeField, nameField, categoryField, quantityField, purchasePriceField, retailPriceField, supplierField;
    private JButton addButton, updateButton, deleteButton, viewButton;
    private JTable productTable;
    private DefaultTableModel tableModel;
    private ProductDAO productDAO;

    public gui() {
        // Initialize ProductDAO
        productDAO = new ProductDAO();

        // Set up the JFrame
        setTitle("Product Management System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create input panel with GridBagLayout
        JPanel inputPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Add padding
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Add fields and labels
        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(new JLabel("Product ID:"), gbc);

        gbc.gridx = 1;
        idField = new JTextField(20);
        inputPanel.add(idField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(new JLabel("Product Code:"), gbc);

        gbc.gridx = 1;
        codeField = new JTextField(20);
        inputPanel.add(codeField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        inputPanel.add(new JLabel("Product Name:"), gbc);

        gbc.gridx = 1;
        nameField = new JTextField(20);
        inputPanel.add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        inputPanel.add(new JLabel("Category:"), gbc);

        gbc.gridx = 1;
        categoryField = new JTextField(20);
        inputPanel.add(categoryField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        inputPanel.add(new JLabel("Quantity:"), gbc);

        gbc.gridx = 1;
        quantityField = new JTextField(20);
        inputPanel.add(quantityField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        inputPanel.add(new JLabel("Purchase Price:"), gbc);

        gbc.gridx = 1;
        purchasePriceField = new JTextField(20);
        inputPanel.add(purchasePriceField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        inputPanel.add(new JLabel("Retail Price:"), gbc);

        gbc.gridx = 1;
        retailPriceField = new JTextField(20);
        inputPanel.add(retailPriceField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 7;
        inputPanel.add(new JLabel("Supplier:"), gbc);

        gbc.gridx = 1;
        supplierField = new JTextField(20);
        inputPanel.add(supplierField, gbc);

        // Add buttons
        gbc.gridx = 0;
        gbc.gridy = 8;
        addButton = new JButton("Add Product");
        inputPanel.add(addButton, gbc);

        gbc.gridx = 1;
        updateButton = new JButton("Update Product");
        inputPanel.add(updateButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 9;
        deleteButton = new JButton("Delete Product");
        inputPanel.add(deleteButton, gbc);

        gbc.gridx = 1;
        viewButton = new JButton("View Products");
        inputPanel.add(viewButton, gbc);

        // Create table model and table
        tableModel = new DefaultTableModel();
        tableModel.addColumn("ID");
        tableModel.addColumn("Name");
        tableModel.addColumn("Code");
        tableModel.addColumn("Category");
        tableModel.addColumn("Quantity");
        tableModel.addColumn("Purchase Price");
        tableModel.addColumn("Retail Price");
        tableModel.addColumn("Supplier");

        productTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(productTable);

        // Add components to the JFrame
        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // Add event listeners
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addProduct();
            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateProduct();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteProduct();
            }
        });

        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewProducts();
            }
        });
    }

    private void addProduct() {
        try {
            int id = Integer.parseInt(idField.getText());
            int code = Integer.parseInt(codeField.getText());
            String name = nameField.getText();
            String category = categoryField.getText();
            int quantity = Integer.parseInt(quantityField.getText());
            double purchasePrice = Double.parseDouble(purchasePriceField.getText());
            double retailPrice = Double.parseDouble(retailPriceField.getText());
            String supplier = supplierField.getText();

            Product product = new Product(id, name, code, category, quantity, purchasePrice, retailPrice, supplier);
            productDAO.addProduct(product);
            JOptionPane.showMessageDialog(this, "Product added successfully!");
            clearFields();
            viewProducts(); // Refresh the table
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please check numeric fields (ID, Code, Quantity, Prices).");
        }
    }

    private void updateProduct() {
        try {
            int id = Integer.parseInt(idField.getText());
            int code = Integer.parseInt(codeField.getText());
            String name = nameField.getText();
            String category = categoryField.getText();
            int quantity = Integer.parseInt(quantityField.getText());
            double purchasePrice = Double.parseDouble(purchasePriceField.getText());
            double retailPrice = Double.parseDouble(retailPriceField.getText());
            String supplier = supplierField.getText();

            Product product = new Product(id, name, code, category, quantity, purchasePrice, retailPrice, supplier);
            productDAO.updateProduct(product);
            JOptionPane.showMessageDialog(this, "Product updated successfully!");
            clearFields();
            viewProducts(); // Refresh the table
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please check numeric fields (ID, Code, Quantity, Prices).");
        }
    }

    private void deleteProduct() {
        try {
            int code = Integer.parseInt(codeField.getText());
            productDAO.deleteProduct(code);
            JOptionPane.showMessageDialog(this, "Product deleted successfully!");
            clearFields();
            viewProducts(); // Refresh the table
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please enter a valid product code.");
        }
    }

    private void viewProducts() {
        tableModel.setRowCount(0); // Clear the table
        List<Product> products = productDAO.getAllProducts();
        for (Product product : products) {
            tableModel.addRow(new Object[]{
                    product.getId(),
                    product.getName(),
                    product.getCode(),
                    product.getCategory(),
                    product.getQuantity(),
                    product.getPurchasePrice(),
                    product.getRetailPrice(),
                    product.getSupplier()
            });
        }
    }

    private void clearFields() {
        idField.setText("");
        codeField.setText("");
        nameField.setText("");
        categoryField.setText("");
        quantityField.setText("");
        purchasePriceField.setText("");
        retailPriceField.setText("");
        supplierField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new gui().setVisible(true);
            }
        });
    }
}