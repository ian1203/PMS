package DAO;

import static java.sql.DriverManager.getConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import Model.Product;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
    private static final Logger logger = LoggerFactory.getLogger(ProductDAO.class);
    private static final String URL = "jdbc:postgresql://localhost:5433/pms";
    private static final String USER = "ianvicente";
    private static final String PASSWORD = "Axcarlo1203@";

    // Get database connection
    private Connection connect() throws SQLException {
        return getConnection(URL, USER, PASSWORD);
    }

    // Insert new product
    public void addProduct(Product product) {
        String sql = "INSERT INTO products (name, code, category, quantity, purchase_price, retail_price, supplier) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = connect();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, product.getName());
            stmt.setInt(2, product.getCode());
            stmt.setString(3, product.getCategory());
            stmt.setInt(4, product.getQuantity());
            stmt.setDouble(5, product.getPurchasePrice());
            stmt.setDouble(6, product.getRetailPrice());
            stmt.setString(7, product.getSupplier());
            stmt.executeUpdate();
        } catch (SQLException e) {
            logger.error("Database error occurred: ", e);
        }
    }

    // Retrieve all products
    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT * FROM products";
        try (Connection conn = connect();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Product product = new Product(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("code"),
                        rs.getString("category"),
                        rs.getInt("quantity"),
                        rs.getDouble("purchase_price"),
                        rs.getDouble("retail_price"),
                        rs.getString("supplier")
                );
                products.add(product);
            }
        } catch (SQLException e) {
            logger.error("Database error occurred: ", e);
        }
        return products;
    }

    // Update a product
    public void updateProduct(Product product) {
        String sql = "UPDATE products SET name=?, category=?, quantity=?, purchase_price=?, retail_price=?, supplier=? WHERE code=?";
        try (Connection conn = connect();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, product.getName());
            stmt.setString(2, product.getCategory());
            stmt.setInt(3, product.getQuantity());
            stmt.setDouble(4, product.getPurchasePrice());
            stmt.setDouble(5, product.getRetailPrice());
            stmt.setString(6, product.getSupplier());
            stmt.setInt(7, product.getCode());
            stmt.executeUpdate();
        } catch (SQLException e) {
            logger.error("Database error occurred: ", e);
        }
    }

    // Delete a product
    public void deleteProduct(int code) {
        String sql = "DELETE FROM products WHERE code=?";
        try (Connection conn = connect();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, code);
            stmt.executeUpdate();
        } catch (SQLException e) {
            logger.error("Database error occurred: ", e);
        }
    }
}